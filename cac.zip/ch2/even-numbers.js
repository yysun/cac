﻿// 从数组中查找出偶数
var numbers = [0, 1, 2, 4, 5, 6, 7, 8, 9];
for (var i = 0; i < numbers.length; i++) {
    if (numbers[i] % 2 === 0) {
        console.log(numbers[i]);
    }
}

















/*
numbers.forEach(function(d){
  if (d % 2 === 0) {
      console.log(d);
  }
});
*/
