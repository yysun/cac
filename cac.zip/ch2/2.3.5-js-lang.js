﻿/*
function add(a, b) {
	return
	a + b;
}

add(1, 2);
*/

var a = 0 var b = 1
